%
% Copyright (c) 2015, Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "license.txt" for license terms.
%
% Project Code: YPEA102
% Project Title: Implementation of Particle Swarm Optimization in MATLAB
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: S. Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%

clc;
clear;
close all;
variables;
ini_it_pso=0;
% Problem Definition
addpath(genpath('D:\��������\pso_no_ml'));
MaxIt=1000;      % Maximum Number of Iterations MaxIt=10000

nPop=10;        % Population Size (Swarm Size) nPop=50
%main_initial_stastic;
it=1;
CostFunction=@(x,i,it,nPop) MMC_Lshape(x,i,it,nPop);        % Cost Function

nVar = 5;    % Number of Decision Variables
VarSize = [1 nVar];

VarMin = [0.3 0.05 0.8 0.4 0.2];   % Lower Bound of Variables VarMin = 1.8
VarMax = [0.4 0.1 1.2 0.8 0.4];   % Upper Bound of Variables VarMax = 2.2

% PSO Parameters



%PSO Parameters
w=1;            % Inertia Weight
wdamp=0.99;     % Inertia Weight Damping Ratio 0.99
c1=1.5;         % Personal Learning Coefficient 1.5
c2=2.0;         % Global Learning Coefficient

%Velocity Limits
VelMax=0.1*(VarMax-VarMin);
VelMin=-VelMax;

% Initialization

%empty_particle.Position=[];
%empty_particle.Cost=[];
%empty_particle.Velocity=[];
%empty_particle.Best.Position=[];
%empty_particle.Best.Cost=[];
%particle=repmat(empty_particle,nPop,1);
empty_particle.Position=cell(1,MaxIt);
empty_particle.Cost=cell(1,MaxIt);
empty_particle.Velocity=cell(1,MaxIt);
empty_particle.Best.Position=cell(1,MaxIt);
empty_particle.Best.Cost=cell(1,MaxIt);
particle=repmat(empty_particle,nPop,1);
GlobalBest.Cost=inf;
%x=zeros(1,5);
a=1
while(a>0)
    for i=1:nPop
    
%    Initialize Position
        for j=1:5
            x(j)=unifrnd(VarMin(j),VarMax(j),1);
        end
        particle(i,:).Position{it}=x;
%        Initialize Velocity
        v = zeros(VarSize);

        particle(i).Velocity{it}=v;
%        Evaluation
        particle(i).Cost{it}=CostFunction(particle(i).Position{it},i,it,nPop);
   
    end
   % ����һ�μ������ɭ��
    system('python test.py');
    [Data]=importdata('class_results-ET_L5.txt');
    data=Data.data;
 
    for i=1:nPop
%    Update Personal Best
        particle(i).Best.Position{it}=particle(i).Position{it};
        particle(i).Best.Cost{it}=particle(i).Cost{it};

 %       Update Global Best
        if particle(i).Best.Cost{it}<GlobalBest.Cost && data(i,2)==1

            GlobalBest.Position=particle(i).Best.Position{it};
            GlobalBest.Cost=particle(i).Best.Cost{it};
            a=0
    end
             
end
    
    
    



end
outputiterop=zeros(MaxIt,2);
BestCost=zeros(MaxIt,1);
% PSO Main Loop

for it=1:MaxIt
    
    for i=1:nPop
        
        % Update Velocity
        particle(i).Velocity{it+1} = w*particle(i).Velocity{it} ...
            +c1*rand(VarSize).*(particle(i).Best.Position{it}-particle(i).Position{it}) ...
            +c2*rand(VarSize).*(GlobalBest.Position-particle(i).Position{it});
        
        % Apply Velocity Limits
        for j=1:5
        particle(i).Velocity{it+1}(j) = max(particle(i).Velocity{it+1}(j),VelMin(j));
        particle(i).Velocity{it+1}(j) = min(particle(i).Velocity{it+1}(j),VelMax(j));
        end
        % Update Position
        particle(i).Position{it+1} = particle(i).Position{it} + particle(i).Velocity{it+1};
        
        % Velocity Mirror Effect
        IsOutside=zeros(1,5);
        for j=1:5
        IsOutside(j)=(particle(i).Position{it+1}(j)<VarMin(j) | particle(i).Position{it+1}(j)>VarMax(j));
        end
        IsOutside=logical(IsOutside);
        particle(i).Velocity{it+1}(IsOutside)=-particle(i).Velocity{it+1}(IsOutside);
        % Apply Position Limits
        for j=1:5
        particle(i).Position{it+1}(j) = max(particle(i).Position{it+1}(j),VarMin(j));
        particle(i).Position{it+1}(j) = min(particle(i).Position{it+1}(j),VarMax(j));
        end
        % Evaluation
        particle(i).Cost{it+1} = CostFunction(particle(i).Position{it+1},i,it,nPop);
        
       %% ����һ�����ɭ��
         system('python test.py');
         [Data]=importdata('class_results-ET_L5.txt');
         data=Data.data;
%         system('python switch.py');
        % Update Personal Best
        if particle(i).Cost{it+1}<particle(i).Best.Cost{it} && data(1,2)==1
            
            particle(i).Best.Position{it+1}=particle(i).Position{it+1};
            particle(i).Best.Cost{it+1}=particle(i).Cost{it+1};
            
            % Update Global Best
            if particle(i).Best.Cost{it+1}<GlobalBest.Cost && data(1,2)==1
                GlobalBest.Position=particle(i).Best.Position{it+1};
                GlobalBest.Cost=particle(i).Best.Cost{it+1};
            end
        else
            particle(i).Best.Position{it+1}=particle(i).Best.Position{it};
            particle(i).Best.Cost{it+1}=particle(i).Best.Cost{it};
            GlobalBest.Position=GlobalBest.Position;
            GlobalBest.Cost=GlobalBest.Cost;
        end
        
    end
    BestCost(it)=GlobalBest.Cost;
    %output the optimum result of each iteration
    for ii=1:nPop
    if  particle(ii).Best.Cost{it+1}==BestCost(it)
        itt=ii;
        outputiterop(it,:)=[ii,it];
        break;
     end
    end
    
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    
    w=w*wdamp;
    
    if it>=50
        if BestCost(it)==BestCost(it-49)
            break;
        end
    end
    save all
    disp('data saved')
end

BestSol = GlobalBest.Position;
% nPopff=find(particle.Best.Cost{MaxIt+1}==min(particle.Best.Cost{MaxIt+1}));
%% Results
path_in1='D:\��������\pso_no_ml\imagese\plot of MMC\';
figure;
plot(BestCost,'LineWidth',2);
% semilogy(BestCost,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
grid on;
name=strcat('pso','MMC');
saveas(gca,[path_in1,name],'jpg');    % ����ͼƬ��������������
for ii=1:nPop
    if min(particle(ii).Best.Cost{it+1})==BestCost(MaxIt,1)
        itt=ii;
        break;
    end
end